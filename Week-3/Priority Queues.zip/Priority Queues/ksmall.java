import java.util.*;
class MinPQ<T extends Comparable<T>>
{
	T []arr;
	int capacity;
	int size;

	MinPQ(int capacity)
	{
		this.capacity=capacity;
		size=1;
		arr=(T[]) new Comparable[capacity];
	}

	public void exchange(int i,int j)
	{
		T temp =arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	public boolean compare(int i,int j)
	{
		if(arr[i].compareTo(arr[j])<0)
			return true;
		return false;
	}

	public void resize(int cap)
	{
		capacity = cap;
		T []temp = (T[]) new Comparable[capacity];
		for(int i=0;i<size;i++)
		{
			temp[i] = arr[i];
		}
		arr=temp;
	}

	public void insert(T el)
	{
		if(size==capacity)
			resize(2*capacity);

		if(size==1)
			arr[size++]=el;
		else
		{
			arr[size++]=el;
			swim(size-1);
		}
	}

	public T delete()
	{
		T v=arr[1];
		exchange(1,size-1);
		size--;
		sink(1);
		return (T)v;
	}

	public T kthSmallest(int n)
	{
		T []q = (T[]) new Comparable[n];
		if(n==0 || n>size)
			System.out.println("errie..");

		int i=1,c=1;
		while(i!=n)
		{
			q[c++] = delete();
			i++;
		}

		T temp = arr[1];
		for(int j=1;j<q.length;j++)
		{
			insert(q[j]);
		}
		return temp;
	}

	public T[] kSmallest(int n)
	{
		T []a = (T[]) new Comparable[n];

		if(n==0 || n>size)
			System.out.println("err");

		for(int i=0;i<n;i++)
		{
			a[i]=delete();
		}

		for(int j=0;j<n;j++)
		{
			insert(a[j]);
		}
		// display();
		return a;
		// System.out.println("....");
	}

	public void swim(int k)
	{
		while(k!=1)
		{
			if(compare(k,k/2))
			{
				exchange(k,k/2);
				k=k/2;
			}
			else
			{
				break;
			}
		}
	}

	public void sink(int k)
	{
		while(2*k+1 <size)
		{
			if(compare(2*k+1,2*k))
			{
				if(compare(2*k+1,k))
				{
					exchange(2*k+1,k);
					k=2*k+1;
				}
				else{
					break;
				}
			}
			else if(compare(2*k,k))
			{
				exchange(2*k,k);
				k=2*k;
			}
			else
			{
				break;
			}
		}
		if(2*k < size)
		{
			if(compare(2*k,k))
			{
				exchange(2*k,k);
				k=2*k;
			}
		}
	}

	public void delMin()
	{
		delete();
	}

	public boolean isEmpty()
	{
		return size==0;
	}

	public void display()
	{
		for(int i=1;i<size;i++)
		{
			System.out.print( arr[i]+" ");
		}
		System.out.println();
	}
}

class Test
{
	public static void main(String[] args) {
		MinPQ<Integer> obj = new MinPQ<Integer>(10);
		obj.insert(9);
		obj.insert(7);
		obj.insert(12);
		obj.insert(14);
		obj.insert(6);
		obj.insert(2);
		obj.insert(18);
		obj.insert(11);
		// obj.insert(3);
		// obj.insert(8);

		obj.display();
		System.out.println(obj.kthSmallest(4));
	}
}