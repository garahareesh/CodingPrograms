
//-----------------------------------------------------------------------------------
import java.util.*;
class MinPQ<T extends Comparable<T>>{
	T[] pq;
	int capacity;
	int size;
	MinPQ(int m){
		pq=(T[]) new Comparable[m];
		capacity=pq.length;
		size=0;
	}
	void sink(int k){
		while((2*k)+1<=size){
			int j=(2*k)+1;
			if(j<size && greater(pq[j],pq[j+1])) j++;
			if(!greater(pq[k],pq[j])) break;
			exchange(k,j);
			k=j;
		}
	}
	void exchange(int i,int j){
		T temp=pq[i];
		pq[i]=pq[j];
		pq[j]=temp;
	}
	void swim(int k){
		System.out.println(k);
		while(k>0 && greater(pq[(k-1)/2],pq[k])){
			exchange(k,(k-1)/2);
			k=(k-1)/2;
		}
	}
	void put(T k){
		pq[size++]=k;
		//System.out.println("size"+pq[size-1]);
		swim(size-1);
	}
	T delete(){
		T temp=pq[0];
		exchange(0,size-1);
		size--;
		sink(0);
		return temp;
	}
	boolean greater(T a,T b){
		return a.compareTo(b)>0;
	}
	// T Ksmallest(int n){
	// 	int i=0;
	// 	int c=0;
	// 	T[] arr=(T[])new Comparable[n];
	// 	if(n<0 || n>size)
	// 		throw new IndexOutOfBoundsException("el not found");
	// 	while(i!=n){
	// 		arr[c++]=delete();
	// 		i++;
	// 	}
	// 	T temp=arr[0];
	// 	for(int j=0;j<arr.length;j++){
	// 		put(arr[j]);
	// 	}
	// 	return temp;
	// }
	void display(){
		String str="";
		if(size==0)
			System.out.println("[]");
		else{
			for(int i=0;i<size;i++){
				str=str+pq[i]+",";
			}
			str=str.substring(0,str.length()-1);
			System.out.println(str);
		}
	}
	public static void main(String[] args) {
		MinPQ pq=new MinPQ(8);
		pq.put(9);
		pq.put(7);
		pq.put(12);
		pq.put(14);
		pq.put(6);
		pq.put(2);
		pq.put(18);
		pq.put(11);
		pq.display();
		pq.delete();
		pq.delete();
		//System.out.println(pq.Ksmallest(4));
		pq.display();
	}
}
class MaxPQ<Key extends Comparable<Key>>{
	Key[] pq;
	int size;
	//int i;
	int capacity;
	MaxPQ(int m){
		pq=(Key[])new Comparable[m+1];
		capacity=pq.length;
		size=0;
		//i=0;
	}
	void exchange(int i,int j){
		Key temp=pq[i];
		pq[i]=pq[j];
		pq[j]=temp;
	}
	void swim(int k){
		// System.out.println(" the no of elements is "+k);
		// System.out.println(pq[k/2]+" the parent and child "+pq[k]);
		while(k>0 && lesser(pq[(k-1)/2],pq[k])){
			exchange(k,(k-1)/2);
			k=(k-1)/2;
		}
	}
	void sink(int k){
		while(2*k+1<=size){
			int j=2*k+1;
			if(j<size && lesser(pq[j],pq[j+1])) j++;
			if(!lesser(pq[k],pq[j])) break;
			exchange(k,j);
			k=j;

		}
	}
	boolean lesser(Key a,Key b){
		return a.compareTo(b)<0;
	}
	void put(Key key){
		pq[size++]=key;
		swim(size-1);
	}
	Key delete(){
		Key temp=pq[0];
		exchange(0,size-1);
		size--;
		sink(0);
		return temp;
	}
	void display(){
		String str="";
		// if(size==0)
		// 	System.out.println("[]");
		
			for(int i=0;i<size;i++){
				str=str+pq[i]+",";
			}
			str=str.substring(0,str.length()-1);
			System.out.println(str);
		
	}
	public static void main(String[] args) {
		MaxPQ pq=new MaxPQ(8);
		pq.put(9);
		pq.put(7);
		pq.put(12);
		pq.put(14);
		pq.put(6);
		pq.put(2);
		pq.put(18);
		pq.put(11);
		pq.display();
		pq.delete();
		pq.delete();
		pq.delete();
		pq.display();
	}
}
class Median
{
	MaxPQ maxpq;
	MinPQ minpq;
	double med;
	Median(int x)
	{
		maxpq=new MaxPQ(x);
		minpq=new MinPQ(x);
		med=0.0;
	}
	public double add(int ele)
	{
		if(minpq.size==0&&maxpq.size==0)
		{
			minpq.put(ele);
		}
		else if(minpq.size-maxpq.size==1 && ele>=med)
		{
			maxpq.put(minpq.delete());
			minpq.put(ele);	
		}
		else if(minpq.size-maxpq.size==1 && ele<med)
		{
			maxpq.put(ele);
		}
		else if(maxpq.size-minpq.size==1&&ele>=med)
		{
			minpq.put(ele);
		}
		else if(maxpq.size-minpq.size==1&&ele<med)
		{
			minpq.put(maxpq.delete());
			maxpq.put(ele);
		}
		else if(minpq.size==maxpq.size && ele<med)
		{
			maxpq.put(ele);
		}
		else
			minpq.put(ele);

		if((minpq.size+maxpq.size)%2==0)
				med=(maxpq.pq[0]+minpq.pq[0])/2.0;
			else if(maxpq.size>minpq.size)
				med=maxpq.pq[0];
			else
				med=minpq.pq[0];
		return med;
	}
	public void display()
	{
		System.out.println(maxpq.toString());
		System.out.println(minpq.toString());
	}
	public static void main(String[] args) {
		Median m=new Median(4);
		System.out.println(m.put(1));
		System.out.println(m.put(2));
		System.out.println(m.put(3));
		System.out.println(m.put(4));
		System.out.println(m.put(5));
		m.display();
	}
}