import java.util.*;
class MinWithOutExchanges<Key extends Comparable<Key>>{
	Key[] pq;
	int size;
	//int i;
	int capacity;
	 MinWithOutExchanges(int m)
	{
		pq=(Key[])new Comparable[m+1];
		capacity=m+1;
		size=0;
		//i=0;
	}
	void exchange(int i,int j){
		Key temp=pq[i];
		pq[i]=pq[j];
		pq[j]=temp;
	}
	void swim(int k){
		// System.out.println(" the no of elements is "+k);
		// System.out.println(pq[k/2]+" the parent and child "+pq[k]);
		// 3 childs-----> replace k/2 with (k+1)/3
		Key temp=pq[k];
		while(k>1){
			int parent=k/2;
			if(greater(pq[parent],temp))
				pq[k]=pq[parent];
			else
				break;
			k=parent;
		}
		pq[k]=temp;
	}
	void sink(int k){
		Key temp=pq[k];
		while(k<=size/2){
			int child=2*k;
			if(lesser(pq[child],temp)){
				if((child+1)<=size && lesser(pq[child+1],pq[child])){
					pq[k]=pq[child+1];
					k=child+1;
				}
				else{
					pq[k]=pq[child];
					k=child;
				}
			}
			else{
				if((child+1<=size) && lesser(pq[child+1],pq[k])){
					pq[k]=pq[child+1];
					k=child+1;
				}
				else
					break;
			}
		}
		pq[k]=temp;
	}
	boolean greater(Key a,Key b){
		return a.compareTo(b)>0;
	}
	boolean lesser(Key a,Key b){
		return a.compareTo(b)<0;
	}
	void put(Key key){
		pq[++size]=key;
		swim(size);
	}
	Key delete(){
		if(size == 0){
			return null;
		}
		Key temp=pq[1];
		exchange(1,size);
		size--;
		sink(1);
		return temp;
	}
	void display(){
		String str="";
		if(size==0)
			System.out.println("[]");
		else{
			for(int i=1;i<=size;i++){
				str=str+pq[i]+",";
			}
			str=str.substring(0,str.length()-1);
			System.out.println(str);
		}
	}
	void kthSmallest(int n){
		ArrayList<Key> al=new ArrayList<Key>();
		for(int i=1;i<n;i++)
		{
			al.add(delete());
		}
		Key temp=delete();
		al.add(temp);
		System.out.println("kth small  "+temp);
		//for ist k small elements
		//System.out.println("kth small  "+al);
		for(int i=0;i<al.size();i++){
			put(al.get(i));
		}
		al.clear();
		//-------------------------
		// MinPQ p1=new MinPQ(n);
		// for(int i=0;i<n;i++){
		// 	 p1.put(delete());

		// }
		// System.out.println(pqays.toString(p1.pq));

	}
	void kthLargest(int n){
		ArrayList<Key> al=new ArrayList<Key>();
		int s=size-n;
		for(int i=0;i<s;i++){
			al.add(delete());
		}
		Key temp=delete();
		al.add(temp);
		System.out.println("k th largest  "+temp);
		for(int i=0;i<al.size();i++){
			put(al.get(i));
		}
		al.clear();
	}

	public static void main(String[] args) {
		MinWithOutExchanges pq=new  MinWithOutExchanges(8);
		pq.put(9);
		pq.put(7);
		pq.put(12);
		pq.put(14);
		pq.put(6);
		pq.put(2);
		pq.put(18);
		pq.put(11);
		pq.display();
		pq.kthSmallest(4);
		pq.kthSmallest(3);
		pq.kthLargest(1);
		pq.kthLargest(2);
		pq.display();
		// System.out.println("dcsja  "+pq.delete());
		// System.out.println("gf   "+pq.delete());
		// System.out.println("sds  "+pq.delete());
		// System.out.println("adas  "+pq.delete());
		// pq.display();
		
	}
}
//-----------------------------------------------------------------------------------
// import java.util.*;
// class MinPQ<T extends Comparable<T>>{
// 	T[] pq;
// 	int capacity;
// 	int size;
// 	MinPQ(int m){
// 		pq=(T[]) new Comparable[m];
// 		capacity=pq.length;
// 		size=0;
// 	}
// 	void sink(int k){
// 		while((2*k)+1<=capacity){
// 			int j=(2*k)+1;
// 			if(j<capacity && greater(pq[j],pq[j+1])) j++;
// 			if(!greater(pq[k],pq[j])) break;
// 			exchange(k,j);
// 			k=j;
// 		}
// 	}
// 	void exchange(int i,int j){
// 		T temp=pq[i];
// 		pq[i]=pq[j];
// 		pq[j]=temp;
// 	}
// 	void swim(int k){
// 		System.out.println(k);
// 		while(k>0 && greater(pq[(k-1)/2],pq[k])){
// 			exchange(k,(k-1)/2);
// 			k=(k-1)/2;
// 		}
// 	}
// 	void put(T k){
// 		pq[size++]=k;
// 		//System.out.println("size"+pq[size-1]);
// 		swim(size-1);
// 	}
// 	T delete(){
// 		T temp=pq[0];
// 		exchange(0,size-1);
// 		size--;
// 		sink(0);
// 		return temp;
// 	}
// 	boolean greater(T a,T b){
// 		return a.compareTo(b)>0;
// 	}
// 	T Ksmallest(int n){
// 		int i=0;
// 		int c=0;
// 		T[] pq=(T[])new Comparable[n];
// 		if(n<0 || n>size)
// 			throw new IndexOutOfBoundsException("el not found");
// 		while(i!=n){
// 			pq[c++]=delete();
// 			i++;
// 		}
// 		T temp=pq[0];
// 		for(int j=0;j<pq.length;j++){
// 			put(pq[j]);
// 		}
// 		return temp;
// 	}
// 	void display(){
// 		String str="";
// 		if(size==0)
// 			System.out.println("[]");
// 		else{
// 			for(int i=0;i<size;i++){
// 				str=str+pq[i]+",";
// 			}
// 			str=str.substring(0,str.length()-1);
// 			System.out.println(str);
// 		}
// 	}
// 	public static void main(String[] args) {
// 		MinPQ pq=new MinPQ(8);
// 		pq.put(9);
// 		pq.put(7);
// 		pq.put(12);
// 		pq.put(14);
// 		pq.put(6);
// 		pq.put(2);
// 		pq.put(18);
// 		pq.put(11);
// 		pq.delete();
// 		pq.delete();
// 		System.out.println(pq.Ksmallest(4));
// 		pq.display();
// 	}
// }