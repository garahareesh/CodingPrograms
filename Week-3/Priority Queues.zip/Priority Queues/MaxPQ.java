class MaxPQ<Key extends Comparable<Key>>{
	Key[] pq;
	int size;
	//int i;
	int capacity;
	MaxPQ(int m){
		pq=(Key[])new Comparable[m+1];
		capacity=pq.length;
		size=0;
		//i=0;
	}
	void exchange(int i,int j){
		Key temp=pq[i];
		pq[i]=pq[j];
		pq[j]=temp;
	}
	void swim(int k){
		// System.out.println(" the no of elements is "+k);
		// System.out.println(pq[k/2]+" the parent and child "+pq[k]);
		while(k>1 && lesser(pq[k/2],pq[k])){
			exchange(k,k/2);
			k=k/2;
		}
	}
	void sink(int k){
		while(2*k<=capacity){
			int j=2*k;
			if(j<capacity && lesser(pq[j],pq[j+1])) j++;
			if(!lesser(pq[k],pq[j])) break;
			exchange(k,j);
			k=j;

		}
	}
	boolean lesser(Key a,Key b){
		return a.compareTo(b)<0;
	}
	void put(Key key){
		// if(size == 0)
		// {
		// 	//System.out.println(" hi");
		// 	pq[size+1]=key;
		// 	size++;
		// }
		// else{
		// 	size++;
		// 	pq[size]=key;
		// 	swim(size);
		// }
		pq[++size]=key;
		swim(size);
	}
	void delete(Key key){
		Key temp=pq[1];
		exchange(1,size);
		size--;
		sink(1);
		//return temp;
	}
	void display(){
		String str="";
		if(size==0)
			System.out.println("[]");
		else{
			for(int i=1;i<pq.length;i++){
				str=str+pq[i]+",";
			}
			str=str.substring(0,str.length()-1);
			System.out.println(str);
		}
	}
	public static void main(String[] args) {
		MaxPQ pq=new MaxPQ(8);
		pq.put(9);
		pq.put(7);
		pq.put(12);
		pq.put(14);
		pq.put(6);
		pq.put(2);
		pq.put(18);
		pq.put(11);
		pq.display();
	}
}